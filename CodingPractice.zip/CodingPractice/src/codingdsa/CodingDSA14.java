package codingdsa;


public class CodingDSA14 {
    
   private String name; 
    private int age;
    
    
    CodingDSA14(){
        name = "Mrudul";
        age = 20;
    }
    
    
    
    void person(){
        System.out.println("Hello my name is: " + name);
        System.out.println("My age is: " + age);
                
                }
    
    public static void main(String[] args){
    
        CodingDSA14 Mrudul = new CodingDSA14();
        Mrudul.person();
              
                
    
    
    }
    
}
