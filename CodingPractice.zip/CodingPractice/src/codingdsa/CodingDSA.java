
package codingdsa;

import java.util.Scanner;

public class CodingDSA {


    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Number 1:");
        int number1 = sc.nextInt();
        
        System.out.println("Enter Number 2:");
        int number2 = sc.nextInt();
        
        System.out.println("The sum of two numbers is " + (number1 + number2));
        
        
    }
    
}
