
package codingdsa;


public class CodingDSA1 {
   public static void main(String[] args) {
       
   byte byte1 = -3; 
   short short1 = 25;
   int int1 = 200;
   long long1 = 100000;
   
   float float1 = 3.42f;
   double double1 = 3.2;
   char char1 = '2';
   boolean boolean1 = true;
   String string1 = "Mrudul";
   
   System.out.println("Byte is: " + byte1);
   System.out.println("short is: " + short1);
   System.out.println("int is: " + int1);
   System.out.println("long is: " + long1);
   System.out.println("float is: " + float1);
   System.out.println("double is: " + double1);
   System.out.println("char is: " + char1);
   System.out.println("boolean is: " + boolean1);
   System.out.println("string is: " + string1);
   
 
   
   
   
    }
}
